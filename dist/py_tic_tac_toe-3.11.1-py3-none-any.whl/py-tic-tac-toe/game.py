print('''X O X
O X O
X X O
''')
